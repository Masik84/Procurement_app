from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional
from decimal import Decimal

from sqlalchemy.orm import Session

from app.db.models import Product, ProductArticle
from app.utils.parsers import parse_loose_number
from app.utils.text import (
    clean_multi_spaces,
    normalize_customer_product_name,
    normalize_product_name,
)


@dataclass(slots=True)
class ProductCreateData:
    name: str
    brand: str
    pack: float
    is_excise: bool


class ProductMatchingService:
    def __init__(self, session: Session) -> None:
        self.session = session
        self._normalized_products_cache: dict[str, Product] | None = None
        self._article_links_cache: dict[str, ProductArticle] | None = None
        self._name_links_cache: dict[str, ProductArticle] | None = None

    def _build_normalized_products_cache(self) -> dict[str, Product]:
        cache: dict[str, Product] = {}
        products = (
            self.session.query(Product)
            .filter(Product.name.isnot(None))
            .order_by(Product.id.asc())
            .all()
        )
        for product in products:
            key = normalize_product_name(product.name)
            if key and key not in cache:
                cache[key] = product
        return cache

    def _build_article_links_cache(self) -> dict[str, ProductArticle]:
        cache: dict[str, ProductArticle] = {}
        links = (
            self.session.query(ProductArticle)
            .filter(ProductArticle.article.isnot(None), ProductArticle.article != "")
            .order_by(ProductArticle.id.asc())
            .all()
        )
        for link in links:
            key = clean_multi_spaces(link.article)
            if key and key not in cache:
                cache[key] = link
        return cache

    def _build_name_links_cache(self) -> dict[str, ProductArticle]:
        cache: dict[str, ProductArticle] = {}
        links = (
            self.session.query(ProductArticle)
            .filter(ProductArticle.name.isnot(None), ProductArticle.name != "")
            .order_by(ProductArticle.id.asc())
            .all()
        )
        for link in links:
            key = clean_multi_spaces(link.name).upper()
            if key and key not in cache:
                cache[key] = link
        return cache

    # =========================================================
    # Article helpers
    # =========================================================

    @staticmethod
    def article_token_normalize(value: object) -> str:
        return clean_multi_spaces(value)

    @classmethod
    def split_article_tokens(cls, article_text: object) -> list[str]:
        raw_text = cls.article_token_normalize(article_text)
        if not raw_text:
            return []

        raw_text = raw_text.replace(",", "/")
        parts = raw_text.split("/")

        result: list[str] = []
        seen: set[str] = set()

        for part in parts:
            token = cls.article_token_normalize(part)
            if not token:
                continue

            token_key = token.casefold()
            if token_key not in seen:
                seen.add(token_key)
                result.append(token)

        return result

    @staticmethod
    def is_pseudo_new_article(article: object) -> bool:
        s = clean_multi_spaces(article).lower()
        return s.startswith("new")

    @classmethod
    def should_create_article_link(cls, article: object) -> bool:
        s = clean_multi_spaces(article)
        return bool(s) and not cls.is_pseudo_new_article(s)

    # =========================================================
    # Pack / family helpers
    # =========================================================

    @staticmethod
    def _normalize_pack_text(value: object) -> str:
        num = parse_loose_number(value)
        if num is None:
            return ""

        if float(num).is_integer():
            return str(int(float(num)))

        s = str(num)
        if "." in s:
            s = s.rstrip("0").rstrip(".")
        return s

    @staticmethod
    def _pack_to_name_format(pack_value: object) -> str:
        s = ProductMatchingService._normalize_pack_text(pack_value)
        if not s:
            return ""

        if "." in s:
            return s.replace(".", ",")

        return s

        s = s.replace(",", ".")
        return s

    @staticmethod
    def _get_trailing_number(value: str) -> str:
        match = re.search(r"([0-9]+(?:[.,][0-9]+)?)\s*$", value.strip(), flags=re.IGNORECASE)
        if not match:
            return ""
        return match.group(1).replace(",", ".")

    @classmethod
    def build_name_with_pack_unit(cls, product_name: object, pack_value: object, unit_text: str) -> str:
        s = normalize_customer_product_name(product_name)
        p_norm = cls._normalize_pack_text(pack_value)
        p_name = cls._pack_to_name_format(pack_value)
        unit_text = clean_multi_spaces(unit_text).upper()

        if not s:
            return ""

        if not p_norm:
            return s

        if re.search(r"([0-9]+(?:[.,][0-9]+)?)\s*(L|KG|л|Л|кг|КГ)\s*$", s, flags=re.IGNORECASE):
            return re.sub(
                r"([0-9]+(?:[.,][0-9]+)?)\s*(L|KG|л|Л|кг|КГ)\s*$",
                rf"\1 {unit_text}",
                s,
                flags=re.IGNORECASE,
            )

        tail_num = cls._get_trailing_number(s)
        if tail_num:
            try:
                if float(tail_num) == float(p_norm):
                    return f"{s} {unit_text}"
            except Exception:
                pass

        return f"{s} {p_name} {unit_text}"
    
    @classmethod
    def build_product_family_from_name(cls, product_name: str, pack_value: object) -> str:
        s_name = clean_multi_spaces(product_name).upper()
        expected_pack = ProductMatchingService._pack_to_name_format(pack_value)

        if not s_name:
            raise ValueError("Не заполнен ProductName.")

        if not expected_pack:
            raise ValueError("Не заполнен Pack.")

        pack_num = parse_loose_number(expected_pack)
        if pack_num is None:
            raise ValueError("Некорректный Pack.")

        matches = list(
            re.finditer(
                r"(?<!\d)([0-9]+(?:[.,][0-9]+)?)\s*(L|KG)\b",
                s_name,
                flags=re.IGNORECASE,
            )
        )

        for match in matches:
            found_num = parse_loose_number(match.group(1))
            if found_num is None:
                continue

            if float(found_num) == float(pack_num):
                family = s_name[:match.start()].strip()
                if not family:
                    raise ValueError(
                        f"Для '{product_name}' не удалось определить family до упаковки."
                    )
                return family

        raise ValueError(
            f"Для '{product_name}' проверь упаковку в названии. "
            f"Ожидается наличие упаковки '{expected_pack}L' или '{expected_pack}KG' "
            f"внутри названия, например: '... {expected_pack}L BIB'."
        )

    # =========================================================
    # Search helpers
    # =========================================================

    def _get_product_by_exact_name(self, product_name: str) -> Optional[Product]:
        return (
            self.session.query(Product)
            .filter(Product.name == product_name)
            .first()
        )

    def _get_article_link_by_exact_article(self, article: str) -> Optional[ProductArticle]:
        key = clean_multi_spaces(article)
        if not key:
            return None
        if self._article_links_cache is None:
            self._article_links_cache = self._build_article_links_cache()
        return self._article_links_cache.get(key)

    def _get_article_link_by_exact_name(self, supplier_name: str) -> Optional[ProductArticle]:
        key = clean_multi_spaces(supplier_name).upper()
        if not key:
            return None
        if self._name_links_cache is None:
            self._name_links_cache = self._build_name_links_cache()
        return self._name_links_cache.get(key)

    def find_by_normalized_product_name(self, source_name: object) -> Optional[Product]:
        target = normalize_product_name(source_name)
        if not target:
            return None
        if self._normalized_products_cache is None:
            self._normalized_products_cache = self._build_normalized_products_cache()
        return self._normalized_products_cache.get(target)

    def find_product_by_split_articles(self, supplier_article: object) -> Optional[Product]:
        first_product: Optional[Product] = None

        for token in self.split_article_tokens(supplier_article):
            link = self._get_article_link_by_exact_article(token)
            if link and link.product:
                if first_product is None:
                    first_product = link.product

        return first_product

    # =========================================================
    # Public matching methods
    # =========================================================

    def find_customer_product(
        self,
        supplier_article: object,
        product_name: object,
        pack: object,
    ) -> Optional[Product]:
        article = clean_multi_spaces(supplier_article)
        name = clean_multi_spaces(product_name)
        normalized_name = normalize_customer_product_name(name)

        if article:
            link = self._get_article_link_by_exact_article(article)
            if link and link.product:
                return link.product

        if name:
            link = self._get_article_link_by_exact_name(name)
            if link and link.product:
                return link.product

            product = self.find_by_normalized_product_name(name)
            if product:
                return product

        if normalized_name and normalized_name != name:
            link = self._get_article_link_by_exact_name(normalized_name)
            if link and link.product:
                return link.product

            product = self.find_by_normalized_product_name(normalized_name)
            if product:
                return product

        name_l = self.build_name_with_pack_unit(name, pack, "L")
        if name_l:
            link = self._get_article_link_by_exact_name(name_l)
            if link and link.product:
                return link.product

            product = self.find_by_normalized_product_name(name_l)
            if product:
                return product

        name_kg = self.build_name_with_pack_unit(name, pack, "KG")
        if name_kg:
            link = self._get_article_link_by_exact_name(name_kg)
            if link and link.product:
                return link.product

            product = self.find_by_normalized_product_name(name_kg)
            if product:
                return product

        return None

    def find_price_import_product(
        self,
        supplier_article: object,
        supplier_product_name: object,
    ) -> Optional[Product]:
        article = clean_multi_spaces(supplier_article)
        name = clean_multi_spaces(supplier_product_name)

        if article:
            product = self.find_product_by_split_articles(article)
            if product:
                return product

        if name:
            link = self._get_article_link_by_exact_name(name)
            if link and link.product:
                return link.product

        if name:
            product = self.find_by_normalized_product_name(name)
            if product:
                return product

        return None

    def find_stock_product(
        self,
        source_article: object,
        source_product_name: object,
    ) -> Optional[Product]:
        name = clean_multi_spaces(source_product_name)
        article = clean_multi_spaces(source_article)

        if name:
            product = self.find_by_normalized_product_name(name)
            if product:
                return product

        if article:
            link = self._get_article_link_by_exact_article(article)
            if link and link.product:
                return link.product

        return None


    def find_is_product(
        self,
        source_article: object,
        source_product_name: object,
    ) -> Optional[Product]:
        article = clean_multi_spaces(source_article)
        name = clean_multi_spaces(source_product_name)

        if article:
            link = self._get_article_link_by_exact_article(article)
            if link and link.product:
                return link.product

        if name:
            exact = self._get_product_by_exact_name(name)
            if exact:
                return exact

            link = self._get_article_link_by_exact_name(name)
            if link and link.product:
                return link.product

            product = self.find_by_normalized_product_name(name)
            if product:
                return product

        return None


    @staticmethod
    def _format_pack_for_message(pack_value: object) -> str:
        if pack_value is None:
            return ""
        s = str(pack_value).strip()
        return s.replace(".", ",")

    @classmethod
    def validate_new_product_fields(
        cls,
        *,
        product_name: object,
        brand: object,
        pack: object,
        is_excise: object,
    ) -> None:
        clean_name = clean_multi_spaces(product_name).upper()
        clean_brand = clean_multi_spaces(brand)
        pack_num = parse_loose_number(pack)

        if not clean_name:
            raise ValueError("Не заполнено название нового продукта.")

        if is_excise is None:
            raise ValueError(f"Для '{clean_name}' не заполнено поле 'Акциз'.")

        if not clean_brand:
            raise ValueError(f"Для '{clean_name}' не заполнено поле 'Бренд'.")

        if pack is None or str(pack).strip() == "":
            raise ValueError(f"Для '{clean_name}' не заполнено поле 'Упаковка'.")

        if pack_num is None:
            raise ValueError(
                f"Для '{clean_name}' поле 'Упаковка' должно быть числом."
            )

        cls.validate_product_name_pack_format(
            product_name=clean_name,
            pack_value=pack_num,
        )

    @classmethod
    def validate_product_name_pack_format(cls, *, product_name: str, pack_value: object) -> None:
        s_name = clean_multi_spaces(product_name).upper()
        expected_pack = cls._pack_to_name_format(pack_value)

        if not s_name:
            raise ValueError("Не заполнено название нового продукта.")

        if not expected_pack:
            raise ValueError(f"Для '{s_name}' не заполнено поле 'Упаковка'.")

        pack_num = parse_loose_number(expected_pack)
        if pack_num is None:
            raise ValueError(f"Для '{product_name}' некорректное поле 'Упаковка'.")

        matches = list(
            re.finditer(
                r"(?<!\d)([0-9]+(?:[.,][0-9]+)?)\s*(L|KG)\b",
                s_name,
                flags=re.IGNORECASE,
            )
        )

        for match in matches:
            found_num = parse_loose_number(match.group(1))
            if found_num is None:
                continue

            if float(found_num) == float(pack_num):
                return

        raise ValueError(
            f"Для '{product_name}' проверь упаковку в названии. "
            f"Ожидается наличие упаковки '{expected_pack}L' или '{expected_pack}KG' "
            f"внутри названия, например: '... {expected_pack}L BIB'."
        )


    def get_or_create_product(
        self,
        *,
        name: object,
        brand: object,
        pack: object,
        is_excise: object,
    ) -> Product:
        clean_name = clean_multi_spaces(name).upper()
        clean_brand = clean_multi_spaces(brand)
        pack_num = parse_loose_number(pack)

        self.validate_new_product_fields(
            product_name=clean_name,
            brand=clean_brand,
            pack=pack_num,
            is_excise=is_excise,
        )

        existing = self._get_product_by_exact_name(clean_name)
        if existing:
            return existing

        normalized_existing = self.find_by_normalized_product_name(clean_name)
        if normalized_existing:
            return normalized_existing

        product = Product()

        if hasattr(product, "name"):
            product.name = clean_name
        if hasattr(product, "brand"):
            product.brand = clean_brand
        if hasattr(product, "pack"):
            product.pack = pack_num
        if hasattr(product, "is_excise"):
            product.is_excise = bool(is_excise)
        if hasattr(product, "family"):
            product.family = self.build_product_family_from_name(clean_name, pack_num)

        self.session.add(product)
        self.session.flush()

        self._normalized_products_cache = None
        return product

    def create_product_article_if_missing(
        self,
        *,
        product_id: int,
        article: object,
        supplier_name: object,
    ) -> Optional[ProductArticle]:
        clean_article = clean_multi_spaces(article)
        clean_name = clean_multi_spaces(supplier_name)

        if not clean_article and not clean_name:
            return None

        existing = (
            self.session.query(ProductArticle)
            .filter(
                ProductArticle.product_id == product_id,
                ProductArticle.article == (clean_article or None),
                ProductArticle.name == (clean_name or None),
            )
            .first()
        )
        if existing:
            return existing

        row = ProductArticle(
            product_id=product_id,
            article=clean_article or None,
            name=clean_name or None,
        )
        self.session.add(row)
        self.session.flush()
        return row

    def save_product_articles_by_split_articles(
        self,
        *,
        product_id: int,
        supplier_article: object,
        supplier_product_name: object,
    ) -> None:
        safe_name = clean_multi_spaces(supplier_product_name)
        tokens = self.split_article_tokens(supplier_article)

        if not tokens:
            if safe_name:
                self.create_product_article_if_missing(
                    product_id=product_id,
                    article=None,
                    supplier_name=safe_name,
                )
            return

        for token in tokens:
            self.create_product_article_if_missing(
                product_id=product_id,
                article=token,
                supplier_name=safe_name or None,
            )

    def create_article_link_from_source(
        self,
        *,
        product_id: int,
        source_article: object,
        source_name: object,
    ) -> None:
        clean_article = clean_multi_spaces(source_article)
        clean_name = clean_multi_spaces(source_name)

        if clean_article:
            if self.should_create_article_link(clean_article):
                self.create_product_article_if_missing(
                    product_id=product_id,
                    article=clean_article,
                    supplier_name=clean_name or None,
                )
        elif clean_name:
            self.create_product_article_if_missing(
                product_id=product_id,
                article=None,
                supplier_name=clean_name,
            )